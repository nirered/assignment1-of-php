<html>
    <head>
   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootst">
    <body class="bg-info">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <Buttton class ="navbar--targgler" type="button" data-toggler="collapse "
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="toggle navigation">
            <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id ="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
            <a class="nav-link" href="index.php">Home<span  class="sr-only">(current)</span></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="create.php">Add a person</a>
</li>
<li class="nav-item">
    <a class="nav-link" href="upload.php">Upload csv file</a>
</li>

</ul>
</div>
</nav>
</body>
</html>